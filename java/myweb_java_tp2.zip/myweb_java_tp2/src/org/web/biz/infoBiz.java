package org.web.biz;

import org.web.entity.Logininfo;

public interface infoBiz {
	public boolean addinfo(Logininfo info);
}
