package org.web.biz;

import org.web.entity.Msgcontent;

public interface msgconBiz {
	public boolean addcon(Msgcontent msgcon);
}
