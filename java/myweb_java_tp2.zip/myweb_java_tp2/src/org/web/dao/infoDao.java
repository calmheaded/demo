package org.web.dao;

import org.web.entity.Logininfo;

public interface infoDao {
	public boolean addinfo(Logininfo info)throws RuntimeException;
}
